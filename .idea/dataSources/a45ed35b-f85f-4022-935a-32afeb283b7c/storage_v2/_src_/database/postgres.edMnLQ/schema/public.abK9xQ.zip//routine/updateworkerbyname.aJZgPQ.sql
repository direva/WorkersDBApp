create function updateworkerbyname(wname character varying, newname character varying, newpr character varying, newpos character varying) returns integer
    language plpgsql
as
$$
declare
nn alias for $2;
npr alias for $3;
npos alias for $4;

begin
update Workers set 
	name = nn, 
	project = npr,
	position = npos
	where Workers.name = $1;
return 1;
end;
$$;

alter function updateworkerbyname(varchar, varchar, varchar, varchar) owner to postgres;

