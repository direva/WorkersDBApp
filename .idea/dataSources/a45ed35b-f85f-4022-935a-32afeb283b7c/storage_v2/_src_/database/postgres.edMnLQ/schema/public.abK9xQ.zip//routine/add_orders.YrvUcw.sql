create function add_orders() returns trigger
    language plpgsql
as
$$
declare
f_from_table int;
s_from_table text;

begin

select f_id into f_from_table from firmService where f_id = NEW.id_firm;
if not found then
	raise exception 'No firm with id %', NEW.id_firm;
else
	select s_list into s_from_table from firmService where f_id = NEW.id_firm;
	if('%' || s_from_table || '%' like cast(NEW.id_service as text)) then
		raise notice '% firm can render % service', NEW.id_firm, NEW.id_service;
	else
		raise exception '% firm cannot render % service', NEW.id_firm, NEW.id_service;
	end if;
end if;

return NEW;
end;
$$;

alter function add_orders() owner to postgres;

