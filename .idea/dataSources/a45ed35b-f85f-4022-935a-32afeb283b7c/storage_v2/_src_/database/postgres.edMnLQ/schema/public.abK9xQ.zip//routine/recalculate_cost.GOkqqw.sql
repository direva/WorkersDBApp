create function recalculate_cost() returns trigger
    language plpgsql
as
$$
declare
cost_without_ex bigint;

begin

if(NEW.exemption <> OLD.exemption) then
	update consumer set (exemption) = (NEW.exemption)
		where consumer.id = OLD.id;	
	cost_without_ex := OLD.actual_cost/(1 - 0.01 * OLD.exemption);
	NEW.actual_cost := cost_without_ex - cost_without_ex * NEW.exemption * 0.01;
	update orders set (actual_cost) = (NEW.actual_cost)
		where id_cons = OLD.id;
end if;
return NEW;
end;
$$;

alter function recalculate_cost() owner to postgres;

