create function findworkerbyname(character varying) returns record
    language plpgsql
as
$$
declare
result record;

begin
select Workers.name, Workers.project, Workers.position into result from Workers where Workers.name = $1;
if not found then
	raise exception '% не числится в базе', $1;
end if;
return result;
end;
$$;

alter function findworkerbyname(varchar) owner to postgres;

