create view actual_orders(type, date, exemption, id, id_order, actual_cost) as
SELECT service.type,
       orders.date,
       consumer.exemption,
       consumer.id,
       orders.id_order,
       orders.actual_cost
FROM service,
     orders,
     consumer
WHERE ((service.id = orders.id_service) AND (consumer.id = orders.id_cons));

alter table actual_orders
    owner to postgres;

