create function cleandb() returns integer
    language plpgsql
as
$$
begin

delete from Workers where Workers.id is not null;

return 1;		
end;
$$;

alter function cleandb() owner to postgres;

