create function createworkersdb() returns integer
    language plpgsql
as
$$
declare
begin

create table Workers (id int primary key check (id>=001),
	              name varchar(100) not null unique,
	              project varchar(100), 
	              position varchar(100));
return 1;		
end;
$$;

alter function createworkersdb() owner to postgres;

