create function addnewworker(name character varying, project character varying, positions character varying) returns integer
    language plpgsql
as
$$
declare
n alias for $1;
pr alias for $2;
pos alias for $3;
wid Workers.id%type;
begin

select max(id) into wid from Workers;
if(wid is null) then
wid = 0;
end if;

insert into Workers values (wid + 1, n, pr, pos);

return 1;		
end;
$$;

alter function addnewworker(varchar, varchar, varchar) owner to postgres;

