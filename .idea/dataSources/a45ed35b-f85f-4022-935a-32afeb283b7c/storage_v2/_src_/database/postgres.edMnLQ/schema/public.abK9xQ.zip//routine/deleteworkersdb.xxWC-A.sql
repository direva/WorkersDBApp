create function deleteworkersdb() returns integer
    language plpgsql
as
$$
declare
begin

drop table Workers;
return 1;		
end;
$$;

alter function deleteworkersdb() owner to postgres;

