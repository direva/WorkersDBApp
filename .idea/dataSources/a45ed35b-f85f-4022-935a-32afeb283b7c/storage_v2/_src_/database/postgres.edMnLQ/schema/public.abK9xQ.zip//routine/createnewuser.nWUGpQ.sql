create function createnewuser(usertype character varying, username character varying, userpass character varying) returns integer
    language plpgsql
as
$$
declare
t alias for $1;
n alias for $2;
p alias for $3;

begin

IF (n is null) THEN
raise exception 'Введите логин';
elseIF (p is null) THEN
raise exception 'Введите пароль';
elseIF (t is null) THEN
raise exception 'Выберите тип пользователя';
else
execute format ('create role %I with login', n);
execute format ('alter role %I with encrypted password ''%I''', n, p);
end if;
if(t = 'adminGroup') then
execute format ('GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO %I', n);
elseif (t = 'userGroup') then
execute format ('GRANT SELECT ON ALL TABLES IN SCHEMA public TO %I', n);
END if;

return 1;
end;
$$;

alter function createnewuser(varchar, varchar, varchar) owner to postgres;

