create function deleteworkerbyname(name character varying) returns integer
    language plpgsql
as
$$
declare
n alias for $1;

begin

delete from Workers where Workers.name = n;

if not found then
raise exception 'Такого работника нет в базе';
end if;

return 1;		
end;
$$;

alter function deleteworkerbyname(varchar) owner to postgres;

